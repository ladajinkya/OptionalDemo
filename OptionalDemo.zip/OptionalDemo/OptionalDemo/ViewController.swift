//
//  ViewController.swift
//  OptionalDemo

import UIKit

class ViewController: UIViewController {
    var commonStr : String?
    override func viewDidLoad() {
        super.viewDidLoad()
        commonStr = "Hello World"
        if let newcommonstr = commonStr
        {
          print("commonStr =\(newcommonstr)")
        }
        else
        {
             print(" if let commonStr is nil")
        }
        guard let newstr = commonStr
        else
        {
            print("Guard commonStr is nil")
            return
        }
        print("Common String = \(commonStr!)")
        struct Device
        {
            var name : String
            var type : String
            var temp : Int
            
        }
        var object : Device?
        //  object = Device(name : "qwerty",type:"iOS",temp :12)
        let newname = object?.name
        let newtype = object?.type
        let newtemp = object?.temp
        guard let var2 = newname, let var1 = newtype
            else
        {
            print("var 1 and var 2 are nil")
            return
        }
        print("var 1 and var 2 are not nil")
        print("vr 1 -\(var1)  vr 2 -\(var2)")
        if let newN = newname
        {
            print("new name = \(newN)")
        }
        else
        {
            print("new name is nil")
        }
        if let newtemp1 = newtemp
        {
            print("new name = \(newtemp1)")
        }
        else
        {
            print("newtemp1 is nil")
        }
        if let newt = newtype
        {
            print("new name = \(newt)")
        }
        else
        {
            print("newt is nil")
        }
        var num : Int?
        num = 10
        guard let number = num else
        {
            print("number is nil")
            return
        }
        print("number is not nil & =\(number)")
        // Do any additional setup after loading the view, typically from a nib.
    }


}

